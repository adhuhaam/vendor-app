/** @format */

import { DeviceEventEmitter } from "react-native";

var AppEventEmitter = DeviceEventEmitter;

export default AppEventEmitter;
